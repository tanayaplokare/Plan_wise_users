@extends('layouts.app')

@push('styles')
{{-- Select2 CSS --}}
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" />
<style>.select2-container{width: 100% !important;}</style>
@endpush

@section('content')
<div class="container">
    <h2>Filter File: {{ $originalUpload->original_filename }}</h2>

    @include('partials.alerts')

    <form action="{{ route('filter.process') }}" method="POST">
        @csrf
        <input type="hidden" name="original_upload_id" value="{{ $originalUpload->id }}">

        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="columns">Select Columns to Filter By</label> {{-- Changed label --}}
                {{-- Change name to columns[] and add multiple attribute --}}
                <select name="column[]" id="columns" class="form-control select2" required multiple>
                    {{-- Placeholder can be set via Select2 JS --}}
                    @foreach ($headers as $header)
                         {{-- Check old('column') which will be an array now --}}
                        <option value="{{ $header }}" {{ (is_array(old('column')) && in_array($header, old('column'))) ? 'selected' : '' }}>{{ $header }}</option>
                    @endforeach
                </select>
                 {{-- Updated error check --}}
                 @error('column') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
                 @error('column.*') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
            </div>

            <div class="col-md-6 mb-3">
                <label for="keywords">Select Keywords (Rows containing any will be removed)</label>
                <select name="keywords[]" id="keywords" class="form-control select2" multiple required>
                    @foreach ($keywords as $keyword)
                         <option value="{{ $keyword }}" {{ (is_array(old('keywords')) && in_array($keyword, old('keywords'))) ? 'selected' : '' }}>{{ $keyword }}</option>
                    @endforeach
                </select>
                 @error('keywords') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
                 @error('keywords.*') <div class="invalid-feedback d-block">{{ $message }}</div> @enderror
            </div>
        </div>

        <div class="mt-3">
            <button type="submit" class="btn btn-primary">Start Filtering</button>
            <a href="{{ route('uploads.index') }}" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
@endsection

@push('scripts')
{{-- Select2 JS --}}
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('#columns').select2({ // Target new ID
            theme: "bootstrap-5",
            placeholder: "Select one or more columns",
            allowClear: true
        });
        $('#keywords').select2({
             theme: "bootstrap-5",
             placeholder: "Select one or more keywords",
             allowClear: true
        });
    });
</script>
@endpush